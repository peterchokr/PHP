<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    메인 화면<br>
    <a href="gaip.php">회원가입</a><br>
</body>    
<?php 
session_start();

if ($_SESSION["ok"] == "")
    echo '<a href="login.php">로그인<a><br>';
else {
    echo '<a href="mail.php">메일<a><br>'; 
    echo '<a href="cartoon.php">만화<a><br>';     
    echo '<a href="logout.php">로그아웃<a><br>';     
}
?>
    <a href="https://www.11st.co.kr/">11번가</a><br>
</html>