<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
session_start();

$id = $_GET["id"];

$con = mysqli_connect("localhost", "user1", "12345", "sample");

$sql = "select * from members where id = '$id'";
$result = mysqli_query($con, $sql);

$cnt = mysqli_num_rows($result);

if ($cnt)
    echo "이미 사용중인 아이디입니다";
else 
{
    echo "사용할 수 있는 아이디입니다";
}
?>
</body>
</html>