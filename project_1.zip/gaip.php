<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        function self_check()
        {
            if (document.ttt.id.value == "")
            {
                alert("아이디를 입력하세요");
                document.ttt.id.focus();
                return;
            }
            if (document.ttt.pass.value == "")
            {
                alert("비밀번호를 입력하세요");
                document.ttt.pass.focus();
                return;
            }            
            if (document.ttt.passx.value == "")
            {
                alert("비밀번호 재확인을 입력하세요");
                document.ttt.passx.focus();
                return;
            }      
            if (document.ttt.pass.value != document.ttt.passx.value)
            {
                alert("비밀번호가 서로 다릅니다.");
                document.ttt.pass.focus();
                return;
            }               
            if (document.ttt.name.value == "")
            {
                alert("이름을 입력하세요");
                document.ttt.name.focus();
                return;
            }  

            document.ttt.submit();

        }



    </script>


</head>
<body>
    회원가입 <br>
    <form name="ttt" action="gaipsave.php" method="post">
    아이디 : <input type="text" name="id" id=""><br>
    비밀번호 : <input type="password" name="pass" id=""><br>
    비밀번호 재확인 : <input type="password" name="passx" id=""><br>
    이름 : <input type="text" name="name" id=""><br>
    메일주소 : <input type="email" name="email" id=""><br>
    <input type="button" value="가입하기" onclick="self_check()">
    <input type="reset" value="취소하기">
    </form>
</body>
</html>