<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        function ttt() 
        {
            if (document.f.id.value == "")
            {
                alert("아이디를 입력하세요");
                document.f.id.focus();
                return
            }
            if (document.f.pass.value == "")
            {
                alert("비밀번호를 입력하세요");
                document.f.pass.focus();
                return
            }    
            
            document.f.submit();
        }
    </script>
</head>
<body>
    로그인 <br>
    <form name="f" action="login002.php" method="post">
    아이디 : <input type="text" name="id" id=""><br>
    비밀번호 : <input type="password" name="pass" id=""><br>
    <input type="button" value="로그인" onclick="ttt()">
    </form>
</body>
</html>