<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        function new_win(){
            window.open("p2.php","ttt","width=500,height=400");
        }


    </script>
</head>
<body>
    메뉴를 선택하면 가격과 판매수량을 볼 수 있습니다.<br>
    <a href="javascript:new_win()">메뉴 찾기</a>
    <form name="clist" action="xxx.php" method="post">
    가격 : <input type="text" name="price" id=""><br>
    판매수량 : <input type="text" name="cnt" id=""><br>
    <input type="submit" value="당일판매정보 기록하기">
    </form>
</body>
</html>