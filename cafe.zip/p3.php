<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>



</head>
<body>
    <?php
    $menu = $_POST["menu"];

    $con = mysqli_connect("localhost", "user1", "12345", "sample");

$sql = "select * from cafe where menu = '$menu'";
$result = mysqli_query($con, $sql);

$cnt = mysqli_num_rows($result);

if ($cnt)
{
    $my = mysqli_fetch_array($result);
    $price = $my["price"];
    $cnt = $my["cnt"];
    echo $menu."   ".$price."  ".$cnt."    ".'<input type="button" value="등록하기" onclick="qqq()">';

}
else 
{
    echo "검색 메뉴는 존재하지 않습니다.";
}
?>

</body>

<script>
    function qqq(){
        opener.document.clist.price.value = '<?= $price ?>';
        opener.document.clist.cnt.value = '<?= $cnt ?>';
    }
</script>
</html>