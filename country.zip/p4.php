<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

</head>
<body>
    <?php
$cname = $_POST["cname"];

$con = mysqli_connect("localhost", "user1", "12345", "sample");
$sql = "select * from country where cname = '$cname'";
$x = mysqli_query($con, $sql);

$cnt = mysqli_num_rows($x);
$row = mysqli_fetch_array($x);


if ($cnt == 0)
{

echo    '<script>
    alert("입력한 국가는 없습니다.")
    </script>';
}
else 
{
    echo $row["cname"]."    ".$row["cc"]."    ".$row["cmoney"]."   ".'<a href="javascript:qqq()">선택</a>';
}
?>

<script>
        function qqq()
        {
            
            opener.document.country.cname.value = '<?= $row["cname"] ?>';
            opener.document.country.cc.value = '<?= $row["cc"] ?>';
            opener.document.country.cmoney.value = '<?= $row["cmoney"] ?>';
        }
    </script>
</body>
</html>