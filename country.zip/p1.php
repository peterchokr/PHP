<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        function ttt()
        {
            window.open("p3.php","mywin","width=500,height=400");

        }


    </script>
</head>
<body>
    사용자가 검색한 나라를 등록해 줍니다.<br>
    <form name="country" action="p2.php" method="post">
    국가명 : <input type="text" name="cname" id="">
    <input type="button" value="찾기" onclick="ttt()"><br>
    수도 : <input type="text" name="cc" id=""><br>
    화폐단위 : <input type="text" name="cmoney" id=""><br>
    <input type="submit" value="등록하기">
    </form>
</body>
</html>