<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        function ttt() {
            if (document.mem.pass.value == "")
            {
                alert("비밀번호가 입력되어야 합니다.");
                document.mem.pass.focus()
                return;
            }    
            if (document.mem.passx.value == "")
            {
                alert("비밀번호 재입력이 입력되어야 합니다.");
                document.mem.passx.focus()
                return;
            }                  
            if (document.mem.pass.value != document.mem.passx.value)
            {
                alert("비밀번호가 일치하지 않습니다.");
                document.mem.pass.focus()
                return;
            }               
            if (document.mem.name.value == "")
            {
                alert("이름이 입력되어야 합니다.");
                document.mem.name.focus()
                return;
            }   
            
            document.mem.submit()
        }

    function kkk(){
        x = document.mem.id.value;
        location.href="idcheck.php?id="+x;
    }
</script>    
</head>
<body>
    <?php 
    session_start() 
    ?>
    <?php
    $con = mysqli_connect("localhost", "user1", "12345", "sample");
    $x = $_SESSION['ok'];
    $sql = "select * from members where id = '$x'";
    $result = mysqli_query($con, $sql);
    $my = mysqli_fetch_array($result);
    ?>
    회원정보 수정 화면 <br>
    <form name="mem" action="update.php" method="post">
    아이디 :  <?= $_SESSION["ok"] ?><br>
    비밀번호 : <input type="text" name="pass" id="" value="<?= $my['pass']?>"><br>
    비밀번호 재확인 : <input type="text" name="passx" id="" value="<?= $my['pass']?>"><br>
    이름 : <input type="text" name="name" id="" value="<?= $my['name']?>"><br>
    이메일 : <input type="email" name="email" id="" value="<?= $my['email']?>"><br>
    <input type="button" value="수정하기" onclick="ttt()">
    <input type="reset" value="취소하기">
    </form>
</body>
</html>