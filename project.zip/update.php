<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
session_start();

$id = $_SESSION["ok"];

$pass = $_POST["pass"];    
$name = $_POST["name"];
$email = $_POST["email"];
$regist_day = date("Y-m-d H:i");

$con = mysqli_connect("localhost", "user1", "12345", "sample");

$sql = "update members set pass = '$pass', name = '$name', email = '$email', regist_day = '$regist_day' where id = '$id'";

mysqli_query($con, $sql);
mysqli_close($con);
?>
<script>
    alert("수정하였습니다.");
    location.href = "main.php";
</script>
</body>
</html>