<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
session_start();

$id = $_SESSION["ok"];

$con = mysqli_connect("localhost", "user1", "12345", "sample");
$sql = "delete from members where id ='$id'";

mysqli_query($con, $sql);
mysqli_close($con);

$_SESSION["ok"] = "";
?>
<script>
    alert("<?= $id ?>" + "인 사용자를 삭제하였습니다.");
</script> 
</body>
</html>