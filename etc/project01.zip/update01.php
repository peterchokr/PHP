<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
session_start();

    // DB에서 검색

    // 1. DB에 연결
    $con = mysqli_connect("localhost", "root", "", "sample");

    // 2. DB 사용(SQL 명령어)
    $uid = $_SESSION["uid"];
    $sql = "select * from mem ";
    $sql = $sql."where uid = '$uid'";

    $output = mysqli_query($con, $sql);
    $row = mysqli_fetch_array($output);

    // $cnt = mysqli_num_rows($output);

    // 3. DB 연결 해제
    mysqli_close($con);

    $utel = explode("-", $row["utel"]);

?>
    <form action="update02.php" method="post">
        아이디 : <?= $row["uid"]?> <br>
        비밀번호 : <?= $row["upwd"]?> <br>
        이름 : <input type="text" name="uname" id="" value="<?= $row['uname']?>"> <br>
        전화번호 : <input type="text" name="utel01" id="" value="<?= $utel[0]?>"> - 
        <input type="text" name="utel02" id="" value="<?= $utel[1]?>"> -
        <input type="text" name="utel03" id="" value="<?= $utel[2]?>"> <br>
        <input type="submit" value="수정하기">
        <input type="reset" value="취소하기">
    </form>




</body>
</html>