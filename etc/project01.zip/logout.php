<?php
session_start();
unset($_SESSION["uid"]);
?>
<script>
    location.href = "main.php";
</script>