<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    session_start();
    $uid = $_POST["uid"];
    $upwd = $_POST["upwd"];

    // DB에서 검색

    // 1. DB에 연결
    $con = mysqli_connect("localhost", "root", "", "sample");

    // 2. DB 사용(SQL 명령어)

    $sql = "select * from mem ";
    $sql = $sql."where uid = '$uid' and upwd = '$upwd'";

    $output = mysqli_query($con, $sql);

    $cnt = mysqli_num_rows($output);

    if (!$cnt)  // !$cnt -> $cnt == 0
    {
        ?>
       
    <script>
        alert("가입한 회원이 아닙니다.");
        history.back();
    </script>

<?php
    }
    else{
        $_SESSION["uid"] = $uid;
?>
<script>
    //alert("로그인되었습니다.");
    location.href = "main.php";

</script>

<?php
    }

    // 3. DB 연결 해제
    mysqli_close($con);
    ?>
</body>
</html>