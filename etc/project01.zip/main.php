<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    사이트 첫화면 <br>
    메뉴 <br>

    <?php
    session_start();
    if (isset($_SESSION["uid"]))
    {
        echo "아이디 : ".$_SESSION["uid"]."<br>";
        echo "<a href='logout.php'>로그아웃</a> <br>";
        echo "<a href='update01.php'>회원정보수정</a> <br>"; 
        echo "<a href='out01.php'>회원탈퇴</a> <br>";               
    ?>
    ----- <br>
    메일 <br>
    쇼핑몰 <br>
    영화 <br>
    야구중계 <br>
    <?php
    }
    else 
    {
        echo '<a href="gaip01.html">회원가입</a> <br>';
        echo '<a href="login01.html">로그인</a> <br>';
    }
    ?>
    ------ <br>
    뉴스보기 <br>
    게시판 <br>

</body>
</html>