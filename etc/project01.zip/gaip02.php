<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $uid = $_POST["uid"];
    $upwd = $_POST["upwd"];
    $uname = $_POST["uname"];
    $utel = $_POST["utel01"]."-".$_POST["utel02"]."-".$_POST["utel03"]; 

    date_default_timezone_set('Asia/Seoul');
    $udate = date("Y-m-d (H:i)");
    
    // DB에 저장(회원가입)

    // 1. DB에 연결
    $con = mysqli_connect("localhost", "root", "", "sample");

    // 2. DB 사용(SQL 명령어)

    $sql = "insert into mem (uid, upwd, uname, utel, udate) ";
    $sql = $sql."values ('$uid', '$upwd', '$uname', '$utel', '$udate')";

    mysqli_query($con, $sql);

    // 3. DB 연결 해제
    mysqli_close($con);
?>
회원가입이 완료되었습니다.  <br>
<a href="main.php">메인으로 가기</a>
</body>
</html>