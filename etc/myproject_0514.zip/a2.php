<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    $uid = $_POST["uid"];
    $upwd = $_POST["upwd01"];  
    $uname = $_POST["uname"];
    $utel = $_POST["utel01"]."-".$_POST["utel02"]."-".$_POST["utel03"]; 
    $udate = date("Y-m-d (H:i)");

    // 1. DB접속
    $con = mysqli_connect("localhost","root","","sample");

    // 2. DB사용 - sql 명령어

    $sql = "insert into myproject (uid, upwd, uname, utel, udate) ";
    $sql .= "values ('$uid', '$upwd', '$uname', '$utel', '$udate')";

    mysqli_query($con,$sql);

    // 3. DB 해제
    mysqli_close($con);
        ?>
    등록하였습니다. <br>
    <a href="main.php">처음으로</a>
</body>
</html>