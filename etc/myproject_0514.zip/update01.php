<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
session_start();
// 1. DB접속
$con = mysqli_connect("localhost","root","","sample");

// 2. DB사용 - sql 명령어
$uid = $_SESSION["uid"];
$sql = "select * from myproject ";
$sql = $sql . "where uid = '$uid'";

$result = mysqli_query($con,$sql);
$row = mysqli_fetch_array($result);

$utel_array = explode("-", $row['utel']);


// 3. DB 해제
mysqli_close($con);    
?>

<form action="update02.php?uid=<?= $row['uid'] ?>" method="post">
        아이디 : <?= $row["uid"] ?>
        <br>
        비밀번호 : <?= $row["upwd"] ?>  <br>
        이름 : <input type="text" name="uname" id="" value='<?= $row["uname"] ?>'>  <br>
        전화번호 : 
        <input type="text" name="utel01" id="" value='<?= $utel_array[0] ?>'> 
        - <input type="text" name="utel02" id="" value='<?= $utel_array[1] ?>'> 
        - <input type="text" name="utel03" id="" value='<?= $utel_array[2] ?>'> <br>
        <input type="submit" value="수정하기">
        <input type="button" value="취소하기"  onclick="history.back()">
    </form>
</body>
</html>