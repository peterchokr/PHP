<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    session_start();
    // 1. DB접속
    $con = mysqli_connect("localhost","root","","sample");

    // 2. DB사용 - sql 명령어
    $uid = $_SESSION["uid"];
    $sql = "delete from myproject where uid = '$uid'";
 
    mysqli_query($con,$sql);

    // 3. DB 해제
    mysqli_close($con);

    unset($_SESSION["uid"]);
    ?>
    
</body>
<script>
    alert("탈퇴하였습니다.");
    location.href="main.php";
</script>
</html>