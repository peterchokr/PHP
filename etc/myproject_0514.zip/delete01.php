<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">[]
    <title>Document</title>
    <?php
    session_start();
    ?>
    <script>
        function udelete(){
        x = confirm("<?= $_SESSION['uid']?>님 탈퇴가 확실합니까?");
        if (x == true) {
            location.href="delete02.php";
        }
        else
        {
            history.back();
        }
        }
        

    </script>

</head>
<body onload="udelete()">

</body>
</html>