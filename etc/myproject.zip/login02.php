<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    session_start();

    $uid = $_POST["uid"];
    $upwd = $_POST["upwd"];    

    // 1. DB접속
    $con = mysqli_connect("localhost","root","","sample");

    // 2. DB사용 - sql 명령어
    $sql = "select * from myproject ";
    $sql = $sql . "where uid = '$uid' and upwd = '$upwd'";

    $result = mysqli_query($con,$sql);

    $cnt = mysqli_num_rows($result);

    if (!$cnt)
    {
    ?>
        <script>
        alert("등록된 사용자가 아닙니다.");
        history.back()
        </script>
<?php
    }
    else 
    {
        echo "로그인 성공";
        $_SESSION["uid"] = $uid;
        echo "<a href='main.php'>처음으로</a>";
    }

    // 3. DB 해제
    mysqli_close($con);    
    ?>
    
</body>
</html>