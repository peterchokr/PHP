<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    사이트 첫화면 <br>
    메뉴 <br>
<?php
session_start();

if (isset($_SESSION["uid"]))
{
    echo "------ <br>";
    echo "<a href='update01.php'>회원정보 수정</a> <br>";
    echo "회원 탈퇴 <br>";
    echo "<a href='logout.php'>로그아웃</a><br>";
    echo "------ <br>";
    echo "메일 <br> 쇼핑몰 <br> 게임 <br>";
}
else 
{
    echo "------ <br>";
    echo "<a href='a1.html'>회원가입</a> <br>";
    echo "<a href='login01.html'>로그인</a> <br>"; 
    echo "------ <br>";       
}

    echo "뉴스보기 <br>    기차 예매 <br>";

?>
</body>
</html>